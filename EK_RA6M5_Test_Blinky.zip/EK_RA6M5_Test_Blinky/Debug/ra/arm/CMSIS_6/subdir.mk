################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CREF += \
EK_RA6M5_Test_Blinky.cref 

MAP += \
EK_RA6M5_Test_Blinky.map 


# Each subdirectory must supply rules for building sources it contributes

